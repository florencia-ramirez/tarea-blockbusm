<!-- Conexion con la base de datos en sí -->
<?php
    $conexion = mysqli_connect("localhost", "root", "", "blockbusm");
?>