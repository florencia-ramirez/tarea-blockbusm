INTEGRANTES:
    Diego Acevedo Santander
        Rol: 202073532-8
    Florencia Ramírez Sancristoful
        Rol: 202073522-0


COSAS QUE NO SE IMPLEMENTARON:
    - Se creó un procedimiento pero no se implementó.
    - No se creó una función.
    - Se puede rentar una película pero no se puede devolver.
    - No se implementó el seguimiento a otros usuarios.
    - No se puede buscar a otros usuarios en la barra de búsqueda.
    - No se implementaron las reseñas de usuario.
    - No se implementaron las funciones de eliminar, editar, o visualizar completamente la información
    del usuario.
    - No se pueden eliminar ni visualizar películas de la wishlist.
    - No se pueden eliminar ni visualizar películas de la lista de favoritos.
    - Al rentar una película no se descuenta el saldo, no disminuye la cantidad de unidades disponibles y
    no aumenta la cantidad de veces que fue rentada.